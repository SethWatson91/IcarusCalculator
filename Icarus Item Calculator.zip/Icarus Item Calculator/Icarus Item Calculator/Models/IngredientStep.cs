﻿namespace Icarus_Item_Calculator.Models
{
    public class IngredientStep
    {
        public string ItemName { get; set; }
        public double Quantity { get; set; }
        public bool IsBase { get; set; }
    }
}
