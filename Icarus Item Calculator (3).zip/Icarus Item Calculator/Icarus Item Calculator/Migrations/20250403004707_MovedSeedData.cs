﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Icarus_Item_Calculator.Migrations
{
    /// <inheritdoc />
    public partial class MovedSeedData : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
